<?php
	$host="127.0.0.1"; // Host name
	$username="root"; // Mysql username
	$password="rootberry";
	$db_name="homeautomation"; // Database name
   
	// Connect to server and select databse.
	mysql_connect("$host", "$username", "$password")or die("Cannot Connect to the database please contact admin.");
	mysql_select_db("$db_name")or die("cannot select DB");
   
   
   
	$id = $_REQUEST['id'];

	$sql = "select IPAddress from device_list where uid = $id";
	$results = mysql_query($sql) or die(mysql_error());
	$row = mysql_fetch_array($results);
	if(mysql_num_rows($results) != 0)
	echo '<iframe src="http://'.$row['IPAddress'].':8080" style="border: 0; position:fixed; top:0; left:0; right:0; bottom:0; width:100%; height:100%"></iframe>';
   
	else
	echo 'No records found on the id';
?>