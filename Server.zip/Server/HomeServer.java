import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;
import java.util.StringTokenizer;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.ws.Dispatch;
import javax.xml.ws.Service;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.http.HTTPBinding; 
import org.w3c.dom.Document;


//GPIO pin related packages
import com.pi4j.io.gpio.GpioController;
import com.pi4j.io.gpio.GpioFactory;
import com.pi4j.io.gpio.RaspiPin;

import com.pi4j.io.gpio.GpioPinDigitalOutput;
import com.pi4j.io.gpio.PinState;

import com.pi4j.io.gpio.GpioPinDigitalInput;
import com.pi4j.io.gpio.PinPullResistance;
import com.pi4j.io.gpio.event.GpioPinDigitalStateChangeEvent;
import com.pi4j.io.gpio.event.GpioPinListenerDigital;


class HomeServer implements Runnable
{
   final static int SWITCH_ON = 1;
   final static int SWITCH_OFF = 0;
   
   final static int SERVER_PORT = 6788;
   
   final static String SWITCH_ON_STR = "ON";
   final static String SWITCH_OFF_STR = "OFF";
   
   final static String LAMP_DEVICE = "Lamp";
   final static String SYSTEM_CMD = "SYSTEM";
   
   final static String GET_STATUS = "GET";
   final static String TOGGLE_STATUS = "TOGGLE";
   final static String SWITCH_OFF_ALL_STATUS = "SWITCHOFFALL";
   
   final static String GPIO_MODE_OUT = "OUT";
   final static String GPIO_MODE_IN = "IN";
   
   final static String DEV_TYPE_SWITCH = "Switch";
   final static String DEV_TYPE_SENSOR = "Sensor";
   
   final static String SYSTEM_SETTINGS = "SYSTEM";
   final static String NOTIFY_SETTINGS = "NOTIFY";
   
   static int deviceStatus = SWITCH_OFF;
   
   final static String SEC_STATUS_STR = "securitystatus";
   final static String OWNER_PHONE_STR = "ownerphone";
   final static String NOTIFY_STATUS_STR = "notification";
   final static String LAST_SMS_TIME = "lastsmstime";
   final static String LAST_SEC_SMS_TIME = "lastsecsms";
   final static String SMS_INTRVL = "smsinterval";
   
   static String uname = "", secstatus = "", phone = "", notification = "";
   static long lastsmstime = 0, smsinterval = 0, lastsecsmstime = 0;
   
   //Trial key valid for 15 attempts
   final static String SMS_LICENSE_KEY = "5DBF265D-AF24-4AB5-866A-F11B24FA8ACA"; 
   
   static Connection conn = null;
   
   private Thread           thread = null;
   private HomeServerThread client = null;
   private ServerSocket     server = null;
   
   static GpioPinDigitalOutput pins[] = new GpioPinDigitalOutput[25];
   static GpioPinDigitalInput pins_in[] = new GpioPinDigitalInput[20];
   
   final static int MASTER_PHONE_INDEX = 0;
   final static int CAM1_INDEX = 1;
   final static int CAM2_INDEX = 2;
   final static int ACC_PHONE_INDEX = 3;
   
   final static String MASTER_PHONE_STR = "MASTER";
   final static String CAM1_PHONE_STR = "CAM1";
   final static String CAM2_PHONE_STR = "CAM2";
   final static String CAM_PHONE_STR = "SECURITYCAM";
   final static String ACC_PHONE_STR = "ACC";
   
   final static int CAM1_UID = 31;
   final static int CAM2_UID = 32;
   final static int ACC_SENSOR_UID = 33;
   final static int MOTION_SENSOR_UID = 21;
   
   //Server commands
   final static String CAMERA_REQUST_COMMAND = "SEND";
   final static String ACK_RESPONSE_COMMAND = "ACK";
   
   static int camRequestIndex = -1;
   
   final static int streamIndexCount = 0;
   
   static BufferedReader GlobalStreamIn[] = new BufferedReader[10];
   static BufferedWriter GlobalStreamOut[] = new BufferedWriter[10];
   

   public static void main(String[] argv) throws InterruptedException, Exception 
   {
	   HomeServer server = new HomeServer(SERVER_PORT);
   }    
    
   private class HomeServerThread extends Thread
   {  
	   private Socket          socket   = null;
	   private HomeServer      server   = null;
	   private int             ID       = -1;
	   private BufferedReader streamIn  = null;
	   private BufferedWriter streamOut = null;
	   char buf[] = new char[4096];
	   boolean isBreakReqd = true;

	   public HomeServerThread(HomeServer _server, Socket _socket)
	   {  
	      server = _server;  socket = _socket;  ID = socket.getPort();
	   }
	   
	   public void run()
	   {
		   while (true)
		   {   
			   try
			   {
				   String status = "";
				   String input = streamIn.readLine();
				   
				   LogMessage("Received request from client");
				   
				   //tokenize the input received
				   StringTokenizer st = new StringTokenizer(input, "|");				   
				   String element = st.nextElement().toString();
				   
				   //find out which device is connecting here...
				   if(element.equalsIgnoreCase(MASTER_PHONE_STR))
				   {
					   LogMessage("Request from Master control device");
				   
					   if(GlobalStreamIn[MASTER_PHONE_INDEX] == null)
					   {
						   GlobalStreamIn[MASTER_PHONE_INDEX] = streamIn;
						   GlobalStreamOut[MASTER_PHONE_INDEX] = streamOut;
					   }
					   
					    //Check the command for what purpose
						if(st.hasMoreElements())
						{
							element = st.nextElement().toString();
							if(element.equalsIgnoreCase(LAMP_DEVICE))
							{
								LogMessage("Requesting operation for " + LAMP_DEVICE);
								status = ApplianceAction(st);
							}
							else if(element.equalsIgnoreCase(SYSTEM_CMD))
							{
								LogMessage("Requesting operation for " + SYSTEM_CMD);
								status = SettingsAction(st);
							}
							else if(element.equalsIgnoreCase(CAMERA_REQUST_COMMAND))
							{
								LogMessage("Requesting operation for " + CAMERA_REQUST_COMMAND);
								isBreakReqd = false;
							}
						}
						
						if(isBreakReqd)
						{
							GlobalStreamOut[MASTER_PHONE_INDEX].write(status);
							GlobalStreamOut[MASTER_PHONE_INDEX].flush();
							                
							GlobalStreamIn[MASTER_PHONE_INDEX] = null;
							GlobalStreamOut[MASTER_PHONE_INDEX] = null;
							
							break;
						}
				   }
				   else if(element.equalsIgnoreCase(CAM_PHONE_STR))
				   {					   
					   //SICURITYCAM|CAMID|IPADDRESS
   					   //tokenize the input received
					   StringTokenizer st1 = new StringTokenizer(input, "|");					   
					   String camid = st.nextElement().toString();
					   String ipaddr = st.nextElement().toString();					   
					   
					   LogMessage("Received request from security camera");
					   	try
					   	{
						    //update table with new sms sent time
							Statement stmt = conn.createStatement();
			                String sql = "update device_list set IPAddress = '" + ipaddr + "' where uid = " + camid;               
			                int res = stmt.executeUpdate(sql);			    			
			    			
			    			stmt.executeQuery ("select location from device_list where uid = " + camid);
							ResultSet rs = stmt.getResultSet();
							while(rs.next())
							{
								 String ret = rs.getString("location");
								 LogMessage("Updated camera status to " + SWITCH_ON_STR + " for camera location " + ret);								 
							}
							rs.close();							
							stmt.close();
			    			
			    			status = SWITCH_ON_STR;			    			
			    			streamOut.write(status);
			    			streamOut.flush();
					   	}
					   	catch(Exception e)
					   	{
					   		LogMessage("Exception " + e.getMessage());
					   	}
		    			break;
				   }				   
				   else if(element.equalsIgnoreCase(ACC_PHONE_STR))
				   {
					   streamOut.write(ACK_RESPONSE_COMMAND);
					   streamOut.flush();
					   
					   LogMessage("Received request from accelerometer phone");
					   
					   try
					   {
						    //Find corresponding device map
						    int devUid2 = 0;
							Statement s = conn.createStatement();
							s.executeQuery ("select devuid from switch_device_map where switchuid = " + ACC_SENSOR_UID);
							ResultSet rs = s.getResultSet();
							while (rs.next())
							{
								devUid2 = rs.getInt ("devuid");								
							}
							rs.close();
							
							if(secstatus.equalsIgnoreCase(SWITCH_ON_STR))
							{	
								LogMessage("Security is switched " + SWITCH_ON_STR + " hence need further action");
								
								//Now toggle this device status..
								int status1 = ControlDevice(TOGGLE_STATUS, ""+devUid2);
								
								//if security is ON then send sms to owners phone as 
								//this could be a security breach.
								if(notification.equalsIgnoreCase(SWITCH_ON_STR))
								{	
									LogMessage("Notification status is " + SWITCH_ON_STR);
									LogMessage("Attempting to send notification to owner phone ");
									
									//Get this device details for messaging.
									//Send sms if not sent in last X time interval
									long curTimeSec = System.currentTimeMillis()/1000;
									//System.out.println("Current time " + curTimeSec);
									
									if((curTimeSec - lastsecsmstime) >= smsinterval)
									{
										String msg = "Accelerometer detected motion at front door.";
										String msg1 = msg.replaceAll(" ", "%20");
										
										lastsecsmstime = curTimeSec;
											
										//Send SMS now
										SMSSend(phone, msg1);
										
										//update table with new sms sent time
										Statement stmt = conn.createStatement();
						                String sql = "update system_settings set value = '" + lastsecsmstime + "' where skey = '" + LAST_SEC_SMS_TIME + "'";               
						                int res = stmt.executeUpdate(sql);
						    			stmt.close();
						    			LogMessage("Successfully sent a notification to owner phone number " + phone);
									}
									else
									{
										LogMessage("A notification already sent at time " + lastsecsmstime + " hence skipping");
									}
								}
							}
							s.close();
							
							break;
					   }
					   catch(Exception e)
					   {}
				   }
			   }
			   catch(IOException ioe) {  }
		   }
		   
		   try
		   {
			   close();
		   }
		   catch(Exception e)
		   {	   }
		   
		   this.stop();
	   }
	   
	   public void open() throws IOException
	   {  
	      streamIn = new BufferedReader(new InputStreamReader(socket.getInputStream()));
	      streamOut = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));	      
	   }
	   
	   public void close() throws IOException
	   {  
		   if (socket != null)    socket.close();
		   if (streamIn != null)  streamIn.close();
	   }
   }
   
   
    public HomeServer(int port)
    {  
    	try
    	{  
    		String userName = "root";
            String password = "rootberry";
            String url = "jdbc:mysql://127.0.0.1/homeautomation";
   		 
            LogMessage("Starting Home Server");
            LogMessage("Verifying database connection");
	   		 try
	   		 {
	   			Class.forName ("com.mysql.jdbc.Driver").newInstance ();
	   			conn = DriverManager.getConnection (url, userName, password);	   			
	   		 }
	   		 catch(Exception e)
	   		 {
	   			LogMessage("Failed to establish database connection");
	   			return;
	   		 }
	   		LogMessage("Database connection verified");
	   		
	   		LogMessage("Initializing GPIO pins status");
	   		 //Initialize and store GPIO pins instances.
            InitGPIOPins();
            LogMessage("GPIO pins initialized");
            
            LogMessage("Switching all devices status to OFF");
            //Reset all devices first time when server starts
            ControlDevice(SWITCH_OFF_ALL_STATUS, "0");
            
            LogMessage("Loading system settings stored into database");
            //Load system setting in memory
            LoadSystemSettings();
            
            server = new ServerSocket(port); 
    		
    		LogMessage("Server started successfully");
    		LogMessage("Server ready to serve requests");
    		start();
    	}
    	catch(IOException ioe)
    	{  
    		LogMessage("Error initializing server status. Please check.");
    	}
    }
    
    public void run()
    {  
    	while (thread != null)
    	{  
    		try
    		{      			
    			addThread(server.accept());
    		}
    		catch(IOException ie)
    		{      			
    			LogMessage("Error while starting server to accept clients");
    		}
    	}
    }
    
    public void addThread(Socket socket)
    {  
    	client = new HomeServerThread(this, socket);
    	try
    	{  
    		client.open();
    		client.start();
    	}
    	catch(IOException ioe)
    	{      		
    		LogMessage("Exception opening connection " + ioe.getMessage());
    	}
    }
    
    public void start()
    {  
    	if (thread == null)
    	{  
    		thread = new Thread(this); 
    		thread.start();
    	}
    }
    
    @SuppressWarnings("deprecation")
	public void stop()
    {  
    	if (thread != null)
    	{  
    		thread.stop(); 
    		thread = null;
    	}
    }
    
    
    //Functions definitions
    public static String SettingsAction(StringTokenizer st)
    {
    	String command = "", status = SWITCH_OFF_STR, node = "";
		
    	LogMessage("Requested for change system settings");
    	
		//Get the command code
		if(st.hasMoreElements())
		{
			command = st.nextElement().toString();
			node = st.nextElement().toString();
		}
		
		status = ControlSettings(command, node);		
		return status;
    }
    
    public static String ControlSettings(String command, String node)
    {
		int status = SWITCH_OFF;
		int pinCnt = 0;

        try
        {   
		    //Get the device status
            if(command.equals(GET_STATUS))
            {
               LogMessage("Requested existing system status");
               LogMessage("Returning back status System security: " + secstatus + " and notification : " + notification);
               return secstatus+"|"+notification;
            }
            else if(command.equals(TOGGLE_STATUS))
            {
               LogMessage("Requested to toggle system status");
               Statement stmt = conn.createStatement();
               String sql = "";
               int res = 0;
               
               if(node.equalsIgnoreCase(SYSTEM_SETTINGS))
               {
            	   LogMessage("Requested to toggle system security settings status. current status : " + secstatus);
            	   //Toggle system status              
                   secstatus = (secstatus.equalsIgnoreCase(SWITCH_ON_STR)?SWITCH_OFF_STR:SWITCH_ON_STR);
	               sql = "update system_settings set value = '" + secstatus + "' where skey = '" + SEC_STATUS_STR + "'";               
	               res = stmt.executeUpdate(sql);
	               LogMessage("Changed system security settings status to : " + secstatus);
               }
               else
               {
            	   LogMessage("Requested to toggle notification settings status. current status : " + secstatus);
            	   //Toggle notification status
            	   notification = (notification.equalsIgnoreCase(SWITCH_ON_STR)?SWITCH_OFF_STR:SWITCH_ON_STR);
            	   sql = "update system_settings set value = '" + notification + "' where skey = '" + NOTIFY_STATUS_STR + "'";               
            	   res = stmt.executeUpdate(sql);
            	   LogMessage("Changed notification settings status to : " + secstatus);
               }
               
			   stmt.close();
			   
			   return secstatus+"|"+notification;
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
            LogMessage ("Exception in system settings update  " + e.getMessage());            
        }
        
        return secstatus;
	}
	
	public static String ApplianceAction(StringTokenizer st)
	{
		String command = "", appUid = "", result = "";
		int status = 0;
		
		//Get the command code
		if(st.hasMoreElements())
		{
			command = st.nextElement().toString();
		}
		
		//Get the appliance uid if any
		if(st.hasMoreElements())
		{
			appUid = st.nextElement().toString();
		}
		
		LogMessage("Requested for appliance action");
		
		status = ControlDevice(command, appUid);
		
		result = (status == SWITCH_ON)?SWITCH_ON_STR:SWITCH_OFF_STR;	
		
		return result;
	}
	
	public static int ControlDevice(String command, String uid)
	{	
		int status = SWITCH_OFF;
		int pinCnt = 0;

        try
        {
		    //Get the device status
            if(command.equals(GET_STATUS) && secstatus.equalsIgnoreCase(SWITCH_ON_STR))
            {               
               Statement s = conn.createStatement();
               s.executeQuery("select status from device_list where uid = " + uid);
               ResultSet rs = s.getResultSet();
               int count = 0;
               
               while(rs.next())
               {
                  status = rs.getInt ("status");
                  ++count;
               }
               
               LogMessage("Requested to get device status for UID: " + uid + " current status: " + status);
               
               rs.close();
               s.close();
               return status;
            }
            else if(command.equals(TOGGLE_STATUS) && secstatus.equalsIgnoreCase(SWITCH_ON_STR))
            {
               //Get current status
			   Statement s = conn.createStatement ();
			   s.executeQuery ("select status, gpiopin from device_list where uid = " + uid);
               ResultSet rs = s.getResultSet ();
               int count = 0;
               while (rs.next())
               {
                  status = rs.getInt ("status");
                  pinCnt = rs.getInt ("gpiopin");
               }
			   rs.close();
               s.close();
               
               LogMessage("Requested toggle device status for UID: " + uid + " current status: " + status);
			   
               //Toggle GPIO if there is any
               if(pinCnt != -1)
            	   ToggleGPIO(((status==SWITCH_ON)?false:true), pinCnt);
               
               Statement stmt = conn.createStatement();
               status = (status==SWITCH_ON)?SWITCH_OFF:SWITCH_ON;
               String sql = "update device_list set status = " + status + " where uid = " + uid;               
               int res = stmt.executeUpdate(sql);
			   stmt.close();
			   
			   LogMessage("Changed device status for UID: " + uid + " to status: " + status);
			   
               return status;
            }
            else if(command.equals(SWITCH_OFF_ALL_STATUS))
            {
               LogMessage("Request to switch off all devices");
            	
               //Get current status
 			   Statement s = conn.createStatement();
 			   s.executeQuery ("select uid, gpiopin from device_list where gpiomode = '" + GPIO_MODE_OUT + "'");
               ResultSet rs = s.getResultSet();
               int iuid = 0;
               while (rs.next())
               {
                   iuid = rs.getInt("uid");
                   pinCnt = rs.getInt ("gpiopin");
                   
                   //Reset GPIO pin state
                   if(pinCnt != -1)
                	   ToggleGPIO(false, pinCnt);
                   
                   //Update database and reset Pin state
                   Statement stmt = conn.createStatement();
                   String sql = "update device_list set status = " + SWITCH_OFF + " where uid = " + iuid;               
                   int res = stmt.executeUpdate(sql);
    			   stmt.close();    			
               }
 			   rs.close();
               s.close();
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
            LogMessage("Cannot connect to database server  " + e.getMessage());
        }
        
        return status;
	}
	
	public static boolean ToggleGPIO(boolean status, int pinCnt)
	{
        // provision gpio pin #01 as an output pin and turn on
        final GpioPinDigitalOutput pin = pins[pinCnt]; //mapGPIOPin(pinCnt);

        LogMessage("Changing device state by writing to GPIO status " + status);
        pin.setState(status);
        
        return true;
	}
	
	public static GpioPinDigitalOutput mapGPIOPin(int pinCnt)
	{
		// create gpio controller
        final GpioController gpio = GpioFactory.getInstance();
        
        GpioPinDigitalOutput pin = null;
        
        // provision gpio pin #01 as an output pin and turn on
        switch(pinCnt)
        {
        	case 1:
        		pin = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_01);
        		break;
        	case 2:
        		pin = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_02);
        		break;
        	case 3:
        		pin = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_03);
        		break;
        	case 4:
        		pin = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_04);
        		break;
        	case 5:
        		pin = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_05);
        		break;
        	case 6:
        		pin = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_06);
        		break;
        	case 7:
        		pin = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_07);
        		break;
        	case 8:
        		pin = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_08);
        		break;
        	case 9:
        		pin = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_09);
        		break;
        	case 10:
        		pin = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_10);
        		break;
        	case 11:
        		pin = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_11);
        		break;
        	case 12:
        		pin = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_12);
        		break;
        	case 13:
        		pin = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_13);
        		break;
        	case 14:
        		pin = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_14);
        		break;
        	case 15:
        		pin = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_15);
        		break;
        	case 16:
        		pin = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_16);
        		break;
        	case 17:
        		pin = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_17);
        		break;
        	case 18:
        		pin = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_18);
        		break;
        	case 19:
        		pin = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_19);
        		break;
        	case 20:
        		pin = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_20);
        		break;
        	case 0:        	
        		pin = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_00);
				break;
			default:
				pin = gpio.provisionDigitalOutputPin(RaspiPin.GPIO_00);
        		break;
        }
        return pin;
	}
	
	public static GpioPinDigitalInput mapGPIOPinIn(int pinCnt)
	{
		// create gpio controller
        final GpioController gpio = GpioFactory.getInstance();
        
        GpioPinDigitalInput pin = null;
        
        // provision gpio pin #01 as an output pin and turn on
        switch(pinCnt)
        {
        	case 1:        		
				pin = gpio.provisionDigitalInputPin(RaspiPin.GPIO_01, PinPullResistance.PULL_DOWN);
        		break;
        	case 2:
        		pin = gpio.provisionDigitalInputPin(RaspiPin.GPIO_02, PinPullResistance.PULL_DOWN);
        		break;
        	case 3:
        		pin = gpio.provisionDigitalInputPin(RaspiPin.GPIO_03, PinPullResistance.PULL_DOWN);
        		break;
        	case 4:
        		pin = gpio.provisionDigitalInputPin(RaspiPin.GPIO_04, PinPullResistance.PULL_DOWN);
        		break;
        	case 5:
        		pin = gpio.provisionDigitalInputPin(RaspiPin.GPIO_05, PinPullResistance.PULL_DOWN);
        		break;
        	case 6:
        		pin = gpio.provisionDigitalInputPin(RaspiPin.GPIO_06, PinPullResistance.PULL_DOWN);
        		break;
        	case 7:
        		pin = gpio.provisionDigitalInputPin(RaspiPin.GPIO_07, PinPullResistance.PULL_DOWN);
        		break;
        	case 8:
        		pin = gpio.provisionDigitalInputPin(RaspiPin.GPIO_08, PinPullResistance.PULL_DOWN);
        		break;
        	case 9:
        		pin = gpio.provisionDigitalInputPin(RaspiPin.GPIO_09, PinPullResistance.PULL_DOWN);
        		break;
        	case 10:
        		pin = gpio.provisionDigitalInputPin(RaspiPin.GPIO_10, PinPullResistance.PULL_DOWN);
        		break;
        	case 11:
        		pin = gpio.provisionDigitalInputPin(RaspiPin.GPIO_11, PinPullResistance.PULL_DOWN);
        		break;
        	case 12:
        		pin = gpio.provisionDigitalInputPin(RaspiPin.GPIO_12, PinPullResistance.PULL_DOWN);
        		break;
        	case 13:
        		pin = gpio.provisionDigitalInputPin(RaspiPin.GPIO_13, PinPullResistance.PULL_DOWN);
        		break;
        	case 14:
        		pin = gpio.provisionDigitalInputPin(RaspiPin.GPIO_14, PinPullResistance.PULL_DOWN);
        		break;
        	case 15:
        		pin = gpio.provisionDigitalInputPin(RaspiPin.GPIO_15, PinPullResistance.PULL_DOWN);
        		break;
        	case 16:
        		pin = gpio.provisionDigitalInputPin(RaspiPin.GPIO_16, PinPullResistance.PULL_DOWN);
        		break;
        	case 17:
        		pin = gpio.provisionDigitalInputPin(RaspiPin.GPIO_17, PinPullResistance.PULL_DOWN);
        		break;
        	case 18:
        		pin = gpio.provisionDigitalInputPin(RaspiPin.GPIO_18, PinPullResistance.PULL_DOWN);
        		break;
        	case 19:
        		pin = gpio.provisionDigitalInputPin(RaspiPin.GPIO_19, PinPullResistance.PULL_DOWN);
        		break;
        	case 20:
        		pin = gpio.provisionDigitalInputPin(RaspiPin.GPIO_20, PinPullResistance.PULL_DOWN);
        		break;
        	case 0:        	
        		pin = gpio.provisionDigitalInputPin(RaspiPin.GPIO_00, PinPullResistance.PULL_DOWN);
				break;
			default:
				pin = gpio.provisionDigitalInputPin(RaspiPin.GPIO_00, PinPullResistance.PULL_DOWN);
        		break;
        }
        return pin;
	}
	
	public static void InitGPIOPins()
	{
		int pinCnt = 0;
		
		try
		{
			//Reset all OUT GPIO pins
			Statement s = conn.createStatement();
			s.executeQuery ("select gpiopin from device_list where gpiomode = '" + GPIO_MODE_OUT + "'");// or gpiomode = '" + GPIO_MODE_IN + "'");
            ResultSet rs = s.getResultSet();
            while (rs.next())
            {
                pinCnt = rs.getInt ("gpiopin");
                
                //Get GPIO pin objects                
                pins[pinCnt] = mapGPIOPin(pinCnt);
            }
			rs.close();
			
			//Start event listeners for all input pins
			s.executeQuery ("select gpiopin from device_list where gpiomode = '" + GPIO_MODE_IN + "'");
            rs = s.getResultSet();
            while (rs.next())
            {
                pinCnt = rs.getInt ("gpiopin");

                //Get GPIO pin objects                
                pins_in[pinCnt] = mapGPIOPinIn(pinCnt);				
				
				LogMessage("Registering event listener for GPIO Pin No. " + pinCnt);
				
				// create and register gpio pin listener
				pins_in[pinCnt].addListener(new GpioPinListenerDigital() {
					@Override
					public void handleGpioPinDigitalStateChangeEvent(GpioPinDigitalStateChangeEvent event) {
						GPIOPinListener(event);
					}
				});			
            }
			rs.close();
            s.close();			
		}
		catch(Exception e)
		{
			LogMessage("Exception initializing GPIO ");
		}		
	}
	
	
	public static void GPIOPinListener(GpioPinDigitalStateChangeEvent event)
	{
		String pinstr = "";
		String deviceType = "";
		int devUid1 = 0, devUid2 = 0, status = 0;
		String loc = "";
		long curTimeSec = 0;
		
		try
		{
			// display pin state on console			
			//Find out pin number that is switched on.
			StringTokenizer st = new StringTokenizer(event.getPin().getName(), " ");
			//Check the command for what purpose
			while(st.hasMoreElements())
			{
				pinstr = st.nextElement().toString();
				pinstr = pinstr.trim();
			}
			
			//Check if this pin correspond to a switch or other sensors..
			Statement s = conn.createStatement();
			s.executeQuery ("select devicetype, uid from device_list where gpiopin = " + pinstr);
			ResultSet rs = s.getResultSet();
			while (rs.next())
			{
				deviceType = rs.getString("devicetype");
				devUid1 = rs.getInt("uid");
			}
			rs.close();
			s.close();
			
			//If this is switch then toggle associated device
			if(deviceType.equalsIgnoreCase(DEV_TYPE_SWITCH))
			{
				if(secstatus.equalsIgnoreCase(SWITCH_ON_STR))
				{						
					//Find corresponding device map
					s = conn.createStatement();
					s.executeQuery ("select devuid from switch_device_map where switchuid = " + devUid1);
					rs = s.getResultSet();
					while (rs.next())
					{
						devUid2 = rs.getInt ("devuid");
					}
					rs.close();
					
					LogMessage("This pin corresponds to a switch " + devUid1 + " managing device " + devUid2);
					LogMessage("Changing corresponding device status " + devUid2);
					
					//Now toggle this device status..
					status = ControlDevice(TOGGLE_STATUS, ""+devUid2);
					
					//if security is ON then send sms to owners phone as 
					//this could be a security breach.
					if(notification.equalsIgnoreCase(SWITCH_ON_STR))
					{				
						//Get this device details for messaging.						
						s.executeQuery ("select devicetype, location from device_list where uid = " + devUid2);
						rs = s.getResultSet();
						while (rs.next())
						{
							deviceType = rs.getString("devicetype");
							loc = rs.getString("location");
						}				
						rs.close();
						
						//Send sms if not sent in last X time interval
						curTimeSec = System.currentTimeMillis()/1000;
						
						if((curTimeSec - lastsmstime) >= smsinterval)
						{
							LogMessage("Sending notification message to owner phone ");
							
							String msg = "Device " + deviceType.toUpperCase() + " at " + loc.toUpperCase() + " turned " + ((status == SWITCH_ON)?SWITCH_ON_STR:SWITCH_OFF_STR);
							String msg1 = msg.replaceAll(" ", "%20");
							
							lastsmstime = curTimeSec;
							
							//Send SMS now
							SMSSend(phone, msg1);
						
							//update table with new sms sent time
							Statement stmt = conn.createStatement();
			                String sql = "update system_settings set value = '" + lastsmstime + "' where skey = '" + LAST_SMS_TIME + "'";               
			                int res = stmt.executeUpdate(sql);
			    			stmt.close();
			    			LogMessage("Notification message sent to owner phone number " + phone);
						}
						else
						{
							LogMessage("No notification sent as one sent at time " + lastsmstime);
						}
					}
				
					s.close();
				}
			}
			else if(deviceType.equalsIgnoreCase(DEV_TYPE_SENSOR))
			{
				if(secstatus.equalsIgnoreCase(SWITCH_ON_STR))
				{	
					//Find corresponding device map
					s = conn.createStatement();
					s.executeQuery ("select devuid from switch_device_map where switchuid = " + devUid1);
					rs = s.getResultSet();
					while (rs.next())
					{
						devUid2 = rs.getInt ("devuid");
					}
					rs.close();
					
					LogMessage("This pin corresponds to a sensor " + devUid1 + " managing device " + devUid2);
					LogMessage("Changing corresponding device status " + devUid2);
					
					//Now toggle this device status..
					status = ControlDevice(TOGGLE_STATUS, ""+devUid2);
					
					//if security is ON then send sms to owners phone as 
					//this could be a security breach.
					if(notification.equalsIgnoreCase(SWITCH_ON_STR))
					{			
						LogMessage("Sending notification message to owner phone ");
						
						//Get this device details for messaging.				
						s.executeQuery ("select devicetype, location from device_list where uid = " + devUid2);
						rs = s.getResultSet();
						while (rs.next())
						{
							deviceType = rs.getString("devicetype");
							loc = rs.getString("location");
						}				
						rs.close();
						
						//Send sms if not sent in last X time interval
						curTimeSec = System.currentTimeMillis()/1000;						
						
						if((curTimeSec - lastsecsmstime) >= smsinterval)
						{
							String msg = "Security Warning sensor detected motion";
							String msg1 = msg.replaceAll(" ", "%20");
							
							lastsecsmstime = curTimeSec;
							
							//Send SMS now
							SMSSend(phone, msg1);
							
							//update table with new sms sent time
							Statement stmt = conn.createStatement();
			                String sql = "update system_settings set value = '" + lastsecsmstime + "' where skey = '" + LAST_SEC_SMS_TIME + "'";               
			                int res = stmt.executeUpdate(sql);
			    			stmt.close();
			    			
			    			LogMessage("Notification message sent to owner phone number " + phone);
						}
						else
						{
							LogMessage("No notification sent as one sent at time " + lastsecsmstime);
						}
					}
				
					s.close();
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	
	public static void SMSSend(String phoneNo, String message)
	{		
		String path = "";
        try{ 
        	path = "http://sms2.cdyne.com/sms.svc/SimpleSMSsend?PhoneNumber=" + phoneNo + "&Message=" + message + "&LicenseKey="+ SMS_LICENSE_KEY;
            URL url = new URL(path); 
	        try{ 
		        InputStream in = url.openStream(); 
		        StreamSource source = new StreamSource(in); 
		        
	            ByteArrayOutputStream bos = new ByteArrayOutputStream();	            
	            StreamResult sr = new StreamResult(bos);
	            Transformer trans = TransformerFactory.newInstance().newTransformer();
	            Properties oprops = new Properties();
	            oprops.put(OutputKeys.OMIT_XML_DECLARATION, "yes");
	            trans.setOutputProperties(oprops);
	            trans.transform(source, sr);            
	            bos.close();
	       }catch(java.io.IOException e){
		    	LogMessage("IOException sending SMS");
		        e.printStackTrace(); 
		    }
		    catch(Exception e)
        	{
		    	LogMessage("Exception sending SMS");
		    	e.printStackTrace();
        	}
	    }
        catch (MalformedURLException e){
        	LogMessage("Malformed URL Exception sending SMS");
	    	e.printStackTrace(); 
        }
    }
	
	public static void EmailSend(String phoneNo, String message)
	{		
		String path = "";
        try{ 
        	URL oracle = new URL("http://www.cs.odu.edu/~akshirsa/contactSupport.php?body=" + message);//("http://www.oracle.com/");
            URLConnection yc = oracle.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
            String inputLine;
            while ((inputLine = in.readLine()) != null) 
            	LogMessage("" + inputLine);
            in.close();
	    }catch (Exception e){ 
	    	 e.printStackTrace(); 
        }
    }
	
	
	public static void LoadSystemSettings()
	{		   
		String str = "";
		
		try
		{
			Statement s = conn.createStatement();		
			ResultSet rs = null;	
			
			s.executeQuery("select value from system_settings where skey = '" + NOTIFY_STATUS_STR + "'");
			rs = s.getResultSet();
			while (rs.next())
			{
				notification = rs.getString("value");
			}			
			rs.close();			
			LogMessage("Loading notification status : " + notification);
			
			//Get security status
			s.executeQuery ("select value from system_settings where skey = '" + SEC_STATUS_STR + "'");
			rs = s.getResultSet();
			while (rs.next())
			{
				secstatus = rs.getString("value");
			}			
			rs.close();
			LogMessage("Loading security settings status : " + secstatus);
			
			//find owners phone number
			s.executeQuery ("select value from system_settings where skey = '" + OWNER_PHONE_STR + "'");
			rs = s.getResultSet();
			while (rs.next())
			{
				phone = rs.getString("value");
			}				
			rs.close();
			LogMessage("Loading owner's phone number : " + phone);
			   
			//Send sms if not sent in last X time interval
			s.executeQuery ("select value from system_settings where skey = '" + LAST_SMS_TIME + "'");
			rs = s.getResultSet();
			while (rs.next())
			{
				str = rs.getString("value");
				lastsmstime = Long.parseLong(str);
			}				
			rs.close();
			LogMessage("Loading last SMS sent time : " + lastsmstime);
			
			s.executeQuery ("select value from system_settings where skey = '" + SMS_INTRVL + "'");
			rs = s.getResultSet();
			while (rs.next())
			{
				str = rs.getString("value");
				smsinterval = Long.parseLong(str);
			}				
			rs.close();
			LogMessage("Loading SMS send interval time : " + smsinterval);
			
			s.executeQuery ("select value from system_settings where skey = '" + LAST_SEC_SMS_TIME + "'");
			rs = s.getResultSet();
			while (rs.next())
			{
				str = rs.getString("value");
				lastsecsmstime = Long.parseLong(str);
			}				
			rs.close();
			LogMessage("Loading last security message sent time : " + lastsecsmstime);
			
			s.close();
		}
		catch(Exception e)
		{
			LogMessage("Exception while loading system settings " + e.getMessage());
			e.printStackTrace();
		}
	}
	
	public static void LogMessage(String msg)
	{
		String timeStamp = new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss").format(Calendar.getInstance().getTime());
		System.out.println(timeStamp + " :: " + msg);
	}
}
